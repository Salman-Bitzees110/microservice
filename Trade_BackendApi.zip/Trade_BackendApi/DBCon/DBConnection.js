

const mysql = require("mysql2");


const connection = mysql.createConnection({
  host: "192.168.29.110",
  database: "btz_xchange_db",
  user: "root",
  password: "Bitzees@2023",
});

// const connection = mysql.createConnection({
//   host: "localhost",
//   database: "btz_xchange_db",
//   user: "root",
//   password: "Salman@110",
// });

module.exports = connection





// node-querybuilder_connection
// // const QueryBuilder = require('node-querybuilder');
// // const settings = {
// //     host: 'localhost',
// //     database: 'btz_xchange_db',
// //     user: 'root',
// //     password: 'Salman@110'
// // };
// // module.exports.dbConn = new QueryBuilder(settings, 'mysql', 'pool');

// mysql connection
// const mysql = require('mysql')

// const connection = mysql.createConnection({
//     host: 'localhost',
//     database: 'btz_xchange_db',
//     user: 'root',
//     password: 'Salman@110'
// })
// module.exports = connection
