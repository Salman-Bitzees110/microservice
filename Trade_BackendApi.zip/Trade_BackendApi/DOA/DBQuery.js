const { insert } = require("@nodejscart/mysql-query-builder");
const { response } = require("express");
const connectDB = require("../DBCon/DBConnection");


module.exports.Create_Update_Buy_order_data = async (
  user_id,
  order_id,
  asset_pair,
  order_type_buy_sell,
  order_type_market_limit,
  quote_value_qty,
  base_order_value,
  at_price,
  order_placed_at,
  c_by,
  currency
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "select locked_balance_btx,current_balance_btx from tbl_user_fiat_wallet_master where cuser_id_btx =? and currency_btx=?",
        [user_id, currency],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.length) {
            const user_current_balance = result.map(
              (a) => a.current_balance_btx
            );

            if (JSON.parse(user_current_balance) >= quote_value_qty) {
              connectDB.query(
                "UPDATE tbl_user_fiat_wallet_master SET locked_balance_btx = locked_balance_btx + ? ,current_balance_btx=current_balance_btx - ?,d_by=? WHERE cuser_id_btx = ? and currency_btx=?",
                [quote_value_qty, quote_value_qty, user_id, user_id, currency],
                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if(result.affectedRows!=0){
                    connectDB.query(
                      "insert into tbl_user_open_order_history (cuser_id_btx, order_id_btx,asset_id_btx,quote_currency_btx,order_type_buy_sell,order_type_market_limit,quote_order_value,base_order_value,at_price,order_placed_at,c_by) values (?, ?, ?,?,?,?,?,?,?,?,?)",
                      [
                        user_id,
                        order_id,
                        asset_pair,
                        currency,
                        order_type_buy_sell,
                        order_type_market_limit,
                        quote_value_qty,
                        base_order_value,
                        at_price,
                        order_placed_at,
                        c_by,
                      ],
                      function (err, result) {
                        if (err) {
                          connectDB.rollback(function () {
                            throw err;
                          });
                        } else if(result.affectedRows!=0) {
                          connectDB.commit();
                          // connectDB.end()
                          resolved(result);
                        }else{
                          connectDB.rollback()
                          reject("No Data");
                        }
                      }
                    );
                  }else{
                    connectDB.rollback()
            reject("No Data");
                  }
                }
              );
            } else if (JSON.parse(user_current_balance) < quote_value_qty) {
              reject("Insufficient Fund");
            }
          } else {
            connectDB.rollback()
            reject("No Data");
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.Create_update_Sell_order_Data = async (
  user_id,
  order_id,
  asset_pair,
  quote_currency,
  order_type_buy_sell,
  order_type_market_limit,
  quote_value_qty,
  base_order_value,
  at_price,
  order_placed_at,
  c_by
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "select locked_balance_btx,current_balance_btx from tbl_user_crypto_assets_balance_details where cuser_id_btx =? and asset_id_btx=?",
        [user_id, asset_pair],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.length) {
            const user_current_balance = result.map(
              (a) => a.current_balance_btx
            );

            if (JSON.parse(user_current_balance) >= base_order_value) {
              connectDB.query(
                "UPDATE tbl_user_crypto_assets_balance_details SET locked_balance_btx =  locked_balance_btx + ? ,current_balance_btx= current_balance_btx - ?,d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
                [
                  base_order_value,
                  base_order_value,
                  user_id,
                  user_id,
                  asset_pair,
                ],

                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if(result.affectedRows!=0) {
                    connectDB.query(
                      "insert into tbl_user_open_order_history (cuser_id_btx, order_id_btx,asset_id_btx,quote_currency_btx,order_type_buy_sell,order_type_market_limit,quote_order_value,base_order_value,at_price,order_placed_at,c_by) values (?, ?, ?,?,?,?,?,?,?,?,?)",
                      [
                        user_id,
                        order_id,
                        asset_pair,
                        quote_currency,
                        order_type_buy_sell,
                        order_type_market_limit,
                        quote_value_qty,
                        base_order_value,
                        at_price,
                        order_placed_at,
                        c_by,
                      ],
                      function (err, result) {
                        if (err) {
                          connectDB.rollback(function () {
                            throw err;
                          });
                        } else if(result.affectedRows!=0) {
                          connectDB.commit();
                          resolved(result);
                          // connectDB.end();
                        }else{
                          connectDB.rollback()
                          reject("err")
                        }
                      }
                    );
                  }else{
                    connectDB.rollback()
                          reject("err")
                  }
                }
              );
            } else if (JSON.parse(user_current_balance) < base_order_value) {
              reject("Insufficient Fund");
            }
          } else {
            connectDB.rollback()
            reject("No Data");
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.cancel_buy_order = async (
  user_id,
  order_id,
  asset_pair,
  currency,
  order_type,
  order_type_market_limit,
  base_order_value,
  quote_order_value,
  order_cancelled_at
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "delete from tbl_user_open_order_history  WHERE cuser_id_btx = ? and order_id_btx=?",
        [1, user_id, user_id, order_id],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else {
            if (result.changedRows != 0) {
              connectDB.query(
                "update tbl_user_fiat_wallet_master set locked_balance_btx=locked_balance_btx - ? , current_balance_btx=current_balance_btx+?,d_by=? where cuser_id_btx=? and currency_btx=?",
                [
                  quote_order_value,
                  quote_order_value,
                  user_id,
                  user_id,
                  currency,
                ],
                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if (result.changedRows != 0) {
                    connectDB.query(
                      "insert into tbl_user_cancelled_order_history (cuser_id_btx,order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_cancelled_at,c_by) values (?,?,?,?,?,?,?,?,?,?)",
                      [
                        user_id,
                        order_id,
                        asset_pair,
                        currency,
                        order_type,
                        order_type_market_limit,
                        base_order_value,
                        quote_order_value,
                        order_cancelled_at,
                        user_id,
                      ],
                      (err, res) => {
                        if (err) {
                          connectDB.rollback(() => {
                            reject("err");
                            throw err;
                          });
                        } else if(res.affectedRows!=0){
                          connectDB.commit();
                          resolved(result);
                          // connectDB.end()
                        }else{
                          connectDB.rollback();
                          reject('err');
                        }
                      }
                    );
                  }
                }
              );
            } else {
              connectDB.rollback();
              reject("err");
            }
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.cancel_sell_order = async (
  user_id,
  order_id,
  asset_pair,
  currency,
  order_type,
  order_type_market_limit,
  base_order_value,
  quote_order_value,
  order_cancelled_at
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "delete from tbl_user_open_order_history  WHERE cuser_id_btx = ? and order_id_btx=?",
        [1, user_id, user_id, order_id],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.changedRows != 0) {
            connectDB.query(
              "UPDATE tbl_user_crypto_assets_balance_details SET locked_balance_btx =  locked_balance_btx - ? ,current_balance_btx= current_balance_btx + ?,d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
              [
                base_order_value,
                base_order_value,
                user_id,
                user_id,
                asset_pair,
              ],
              function (err, result) {
                if (err) {
                  connectDB.rollback(function () {
                    throw err;
                  });
                } else if (result.changedRows != 0) {
                  connectDB.query(
                    "insert into tbl_user_cancelled_order_history (cuser_id_btx,order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_cancelled_at,c_by) values (?,?,?,?,?,?,?,?,?,?)",
                    [
                      user_id,
                      order_id,
                      asset_pair,
                      currency,
                      order_type,
                      order_type_market_limit,
                      base_order_value,
                      quote_order_value,
                      order_cancelled_at,
                      user_id,
                    ],
                    (err, res) => {
                      if (err) {
                        connectDB.rollback(() => {
                          reject("err");
                          throw err;
                        });
                      } else if(res.affectedRows!=0){
                        connectDB.commit();
                        resolved(result);
                        // connectDB.end()
                      }else{
                        connectDB.rollback();
                  reject("err");
                      }
                    }
                  );
                } else {
                  connectDB.rollback();
                  reject("err");
                }
              }
            );
          } else {
            connectDB.rollback(function () {
              reject("err");
            });
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.Update_swap_data = async (
  user_id,
  base_asset_value,
  effective_base_value,
  base_asset_id,
  quote_asset_id,
  swap_order_id,
  swap_fee,
  quote_asset_value,
  swap_at
) => {
  // Update user & admin crypto data 1) Debit base asset from user_tbl 2)Credit base asset to admin tbl  3)debit admin quote asset - swap fee
  //    4) credit user quote asset  - swap fee   5) add swap fee details in swap_fee table 6)add swap trxn in tbl_swap_trxn_details

  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "update tbl_user_crypto_assets_balance_details set main_balance_btx=main_balance_btx - ?,current_balance_btx=current_balance_btx - ?  where cuser_id_btx =? and asset_id_btx=?",
        [quote_asset_value, quote_asset_value, user_id, quote_asset_id],

        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.changedRows != 0) {
            connectDB.query(
              "update tbl_user_crypto_assets_balance_details set main_balance_btx=main_balance_btx + ?,current_balance_btx=current_balance_btx + ?  where cuser_id_btx = ? and asset_id_btx=?",
              [
                effective_base_value,
                effective_base_value,
                user_id,
                base_asset_id,
              ],
              function (err, result) {
                if (err) {
                  connectDB.rollback(function () {
                    throw err;
                  });
                } else if (result.changedRows != 0) {
                  connectDB.query(
                    "update tbl_admin_crypto_wallet_master set main_balance_btz=main_balance_btz + ?,current_balance_btz=current_balance_btz + ?  where asset_id_btz=?",
                    [quote_asset_value, quote_asset_value, quote_asset_id],
                    function (err, result) {
                      if (err) {
                        connectDB.rollback(function () {
                          throw err;
                        });
                      } else if (result.changedRows != 0) {
                        connectDB.query(
                          "update tbl_admin_crypto_wallet_master set main_balance_btz=main_balance_btz - ?,current_balance_btz=current_balance_btz - ?  where asset_id_btz=?",
                          [
                            effective_base_value,
                            effective_base_value,
                            base_asset_id,
                          ],
                        async  function (err, result) {
                            if (err) {
                              connectDB.rollback(function () {
                                throw err;
                              });
                            } else if (result.affectedRows != 0) {
                              const last_bal = await getLastEntryFromTableUniversal('tbl_swap_fee_details','swap_fee_wallet_balance')
                              
                               const last_balance = last_bal.map(a=>a.swap_fee_wallet_balance)
                               const updated_Fee = JSON.parse(last_balance) + swap_fee
                              connectDB.query(
                                "insert into tbl_swap_fee_details (cuser_id_btx,swap_order_id_btx,swap_fee_recieved,swap_at,swap_fee_wallet_balance,swap_fee_wallet_updated_at) values (?,?,?,?,?,?)",
                                [user_id, swap_order_id, swap_fee,Date.now(),updated_Fee,Date.now()],

                                function (err, result) {
                                  if (err) {
                                    connectDB.rollback(function () {
                                      throw err;
                                    });
                                  } else if (result.affectedRows != 0) {
                                    connectDB.query(
                                      "insert tbl_user_swap_assets_trxn_details (cuser_id_btx,from_asset_id_btx,to_asset_id_btx,from_asset_value,to_asset_value,swap_fee,swap_date_time,trxn_id)values (?,?,?,?,?,?,?,?)",
                                      [
                                        user_id,
                                        quote_asset_id,
                                        base_asset_id,
                                        quote_asset_value,
                                        base_asset_value,
                                        swap_fee,
                                        Date.now(),
                                        swap_order_id,
                                      ],
                                      function (err, result) {
                                        if (err) {
                                          connectDB.rollback(function () {
                                            throw err;
                                          });
                                        } else if (result) {
                                          connectDB.commit(function () {
                                            resolved(result);
                                          });
                                        }
                                      }
                                    );
                                  } else {
                                    connectDB.rollback(function () {
                                      throw err;
                                    });
                                  }
                                }
                              );
                            } else {
                              connectDB.rollback(function () {
                                throw err;
                              });
                            }
                          }
                        );
                      } else {
                        connectDB.rollback();
                        reject();
                      }
                    }
                  );
                } else {
                  connectDB.rollback();
                  reject();
                }
              }
            );
          } else {
            connectDB.rollback();
            reject();
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.Update_data_P2P_sell_asset = async (
  user_id,
  order_id,
  asset_id,
  asset_rate,
  asset_volume,
  fiat_rate,
  XID,
  order_type_buy_sell,
  order_placed_at,
  c_by
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      connectDB.query(
        "select locked_balance_btx,current_balance_btx from tbl_user_crypto_assets_balance_details where cuser_id_btx =? and asset_id_btx=?",
        [user_id, asset_id],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.length) {
            const user_current_balance = result.map(
              (a) => a.current_balance_btx
            );

            if (JSON.parse(user_current_balance) >= asset_volume) {
              connectDB.query(
                "UPDATE tbl_user_crypto_assets_balance_details SET locked_balance_btx =  locked_balance_btx + ? ,current_balance_btx= current_balance_btx - ?,d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
                [asset_volume, asset_volume, user_id, user_id, asset_id],

                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if (result.affectedRows != 0) {
                    connectDB.query(
                      "insert into tbl_user_p2p_open_order_history (cuser_id_btx, order_id_btx,asset_id_btx,asset_rate,asset_volume,fiat_rate,XID,order_type_buy_sell,order_placed_at,c_by) values (?, ?, ?,?,?,?,?,?,?,?)",
                      [
                        user_id,
                        order_id,
                        asset_id,
                        asset_rate,
                        asset_volume,
                        fiat_rate,
                        XID,
                        order_type_buy_sell,
                        order_placed_at,
                        c_by,
                      ],
                      function (err, result) {
                        if (err) {
                          connectDB.rollback(function () {
                            throw err;
                          });
                        } else {
                          connectDB.commit();
                          resolved("DataBase Updated");
                          // connectDB.end();
                        }
                      }
                    );
                  }
                }
              );
            } else if (JSON.parse(user_current_balance) < asset_volume) {
              reject("Insufficient Fund");
            }
          } else {
            connectDB.rollback();
            reject("No Data");
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.Cancel_P2P_BUY_order = async (
  user_id,
  order_id,
  asset_id,
  asset_rate,
  asset_volume,
  fiat_rate,
  XID,
  order_type_buy_sell,
  canceled_at,
  c_by
) => {
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      if (order_type_buy_sell == "BUY") {
        connectDB.query(
          "UPDATE tbl_user_p2p_open_order_history SET is_deleted = ?,d_by=? WHERE cuser_id_btx = ? and order_id_btx=?",
          [1, user_id, user_id, order_id],
          function (err, result) {
            if (err) {
              connectDB.rollback(function () {
                throw err;
              });
            } else if (result.changedRows != 0) {
              connectDB.query(
                "insert into tbl_p2p_canceled_order_history (cuser_id_btx,order_id_btx,asset_id,asset_rate,asset_volume,fiat_rate,XID,order_type_buy_sell,canceled_at,c_by) values (?,?,?,?,?,?,?,?,?,?)",
                [
                  user_id,
                  order_id,
                  asset_id,
                  asset_rate,
                  asset_volume,
                  fiat_rate,
                  XID,
                  order_type_buy_sell,
                  canceled_at,
                  c_by,
                ],
                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if (result.affectedRows) {
                    connectDB.commit(function () {
                      resolved(result);
                    });
                  } else {
                    connectDB.rollback();
                    reject("err");
                  }
                }
              );
            } else {
              connectDB.rollback(function () {
                reject("err");
              });
            }
          }
        );
      } else if (order_type_buy_sell == "SELL") {
        connectDB.query(
          "UPDATE tbl_user_p2p_open_order_history SET is_deleted = ?,d_by=? WHERE cuser_id_btx = ? and order_id_btx=?",
          [1, user_id, user_id, order_id],
          function (err, result) {
            if (err) {
              connectDB.rollback(function () {
                throw err;
              });
            } else if (result.changedRows != 0) {
              connectDB.query(
                "insert into tbl_p2p_canceled_order_history (cuser_id_btx,order_id_btx,asset_id,asset_rate,asset_volume,fiat_rate,XID,order_type_buy_sell,canceled_at,c_by) values (?,?,?,?,?,?,?,?,?,?)",
                [
                  user_id,
                  order_id,
                  asset_id,
                  asset_rate,
                  asset_volume,
                  fiat_rate,
                  XID,
                  order_type_buy_sell,
                  canceled_at,
                  c_by,
                ],
                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if (result.affectedRows != 0) {
                    connectDB.query(
                      "UPDATE tbl_user_crypto_assets_balance_details SET locked_balance_btx =  locked_balance_btx - ? ,current_balance_btx= current_balance_btx + ?,d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
                      [asset_volume, asset_volume, user_id, user_id, asset_id],
                      function (err, res) {
                        if (err) {
                          connectDB.rollback(function () {
                            throw err;
                          });
                        } else if (result.affectedRows != 0) {
                          connectDB.commit(function () {
                            resolved(result);
                            console.log(result);
                          });
                        }
                      }
                    );
                  } else {
                    connectDB.rollback();
                    reject("err");
                  }
                }
              );
            } else {
              connectDB.rollback(function () {
                reject("err");
              });
            }
          }
        );
      }
    });
  }).catch((e) => {
    return e;
  });
};

const getLastEntryFromTableUniversal = async (
  table_name,
  column_name
) => {
  return await new Promise((resolved, reject) => {
    var sql = `SELECT (${column_name}) FROM ${table_name} WHERE id =(SELECT max(id) FROM ${table_name})`;
    connectDB.query(sql, function (err, result) {
      if (err) throw err;
      console.log(result);
      resolved(result);
    });
  });
};

module.exports.getLastEntryFromTableUniversal = getLastEntryFromTableUniversal;

module.exports.Create_Universal_Data = async function (
  database_table_name,
  obJdata
) {
  return await new Promise((resolved, reject) => {
    var abkey = Object.keys(obJdata);
    var abvalue = Object.values(obJdata);
    var sql = `INSERT INTO ${database_table_name} (${abkey}) VALUES ?`;
    var values = [abvalue];
    connectDB.query(sql, [values], function (err, result) {
      if (err) throw err;
      resolved(result);
    });
  });
};

module.exports.p2p_after_payment_verification_update = async (
  user_id,
  order_id,
  asset_id,
  asset_volume,
  receiver_user_id,
  effective_receiver_volume,
  p2p_fee_received,
  buyer_payment_ss,
  buyer_payment_amount,
) => {
  console.log(user_id, asset_id);
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      console.log(asset_id,asset_volume,user_id,receiver_user_id)
      connectDB.query(
        "UPDATE tbl_user_crypto_assets_balance_details SET locked_balance_btx =  locked_balance_btx - ? ,main_balance_btx= main_balance_btx - ?, d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
        [asset_volume, asset_volume, receiver_user_id, user_id, asset_id],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else if (result.affectedRows != 0) {
            console.log("query 1");
             
            connectDB.query(
              "UPDATE tbl_user_crypto_assets_balance_details SET main_balance_btx =  main_balance_btx + ? ,current_balance_btx= current_balance_btx + ?,d_by=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
              [
                effective_receiver_volume,
                effective_receiver_volume,
                user_id,
                receiver_user_id,
                asset_id,
              ],

              function (err, result) {
                if (err) {
                  connectDB.rollback(function () {
                    throw err;
                  });
                } else if (result.affectedRows != 0) {
                  console.log("query 2");
                  connectDB.query(
                    "UPDATE tbl_admin_crypto_wallet_master SET main_balance_btz =  main_balance_btz + ? ,current_balance_btz= current_balance_btz + ?,d_by=? WHERE asset_id_btz = ?",
                   [
                      p2p_fee_received,
                      p2p_fee_received,
                      receiver_user_id, // fee added by this user so d_by is receiver user id
                      asset_id,
                    ],
                    async function (err, result) {
                      if (err) {
                        connectDB.rollback( function () {
                          throw err;
                        });
                      } else if (result) {
                        const p2p_fee_bal =await getLastEntryFromTableUniversal(
                          "tbl_p2p_fee_details",
                          "p2p_wallet_balance"
                        );
                        const p2p_fee_balance = p2p_fee_bal.map(a=>a.p2p_wallet_balance)
                        if(!p2p_fee_bal.length){
                          reject("NO Data")
                          connectDB.rollback();
                        }
                        connectDB.query(
                          "insert into tbl_p2p_fee_details (cuser_id_btx,trxn_id_btx,trxn_at,p2p_fee_recieved,p2p_wallet_balance,p2p_wallet_updated_at,c_by) values (?,?,?,?,?,?,?)",
                          [
                            receiver_user_id,
                            order_id,
                            Date.now(),
                            p2p_fee_received,
                            JSON.parse(p2p_fee_balance) + p2p_fee_received,
                            Date.now(),
                            user_id
                          ],
                          function (err, result) {
                            if (err) {
                              connectDB.rollback(function () {
                                throw err;
                              });
                            } else if(result.affectedRows != 0){
                              connectDB.query(
                                "delete from tbl_user_p2p_open_order_history where order_id_btx=?",
                                [order_id],
                                function (err, result) {
                                  if (err) {
                                    connectDB.rollback(function () {
                                      throw err;
                                    });
                                  } else if(result.affectedRows != 0) {
                                    connectDB.query(
                                      "insert into tbl_user_p2p_buy_sell_order_history (order_id,seller_user_id_btx,buyer_user_id_btx,asset_id_btx,asset_volume,reciepient_asset_volume,buyer_payment_ss,buyer_payment_amount,buyer_payment_status,seller_credit_status,transaction_fee,transaction_date_time,c_by)values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                      [
                                        order_id,
                                        user_id,
                                        receiver_user_id,
                                        asset_id,
                                        asset_volume,
                                        effective_receiver_volume,
                                        buyer_payment_ss,
                                        buyer_payment_amount,
                                        "1",
                                        "1",
                                        p2p_fee_received,
                                        Date.now(),
                                        user_id,
                                      ],
                                      function (err, result) {
                                        if (err) {
                                          connectDB.rollback(function () {
                                            throw err;
                                          });
                                        } else if (result.affectedRows != 0) {
                                          connectDB.commit();
                                          resolved("DataBase Updated");
                                          // connectDB.end();
                                        }else{
                                          reject("NO Data")
                                          connectDB.rollback();
                                      }
                                      }
                                    );
                                  }else{
                                    reject("NO Data")
                                    connectDB.rollback();
                                }
                                }
                              );
                            }else{
                              reject("NO Data")
                              connectDB.rollback();
                          }
                          }
                        );
                      }else{
                        reject("NO Data")
                        connectDB.rollback();
                    }
                    }
                  );
                }else{
                  console.log("q2")
                  reject("NO Data")
                  connectDB.rollback();
              }
              }
            );
          }else{
            console.log("q1")
              reject("NO Data")
              connectDB.rollback();
          }
        }
      );
    });
  }).catch((e) => {
    return e;
  });
};

module.exports.Get_All_Universal_Data = async function (
  data,
  database_table_name
) {
  return await new Promise((resolved, reject) => {
    var sql = `SELECT ${data} FROM ${database_table_name};`;
    connectDB.query(sql, function (err, result) {
      if (err) throw err;
      resolved(result);
    });
  });
};

module.exports.Get_Where_Universal_Data = async function (
  data,
  database_table_name,
  filterquery
) {
  return await new Promise((resolved, reject) => {
    var abkey = Object.keys(filterquery);
    var abvalue = Object.values(filterquery);
    const abkeydata = abkey.join("=? and ") + "=?";

    var sql = `SELECT ${data} FROM ${database_table_name} WHERE ${abkeydata}`;
    connectDB.query(sql, abvalue, function (err, result) {
      if (err) throw err;
      resolved(result);
    });
  });
};

module.exports.Update_Universal_Data = async function (
  database_table_name,
  updatedata,
  filterquery
) {
  return await new Promise((resolved, reject) => {
    var abkey = Object.keys(updatedata);
    var abvalue = Object.values(updatedata);
    const abkeydata = abkey.join("= ? , ") + "= ? ";
    ////////////////////////

    var filterkey = Object.keys(filterquery);
    var filtervalue = Object.values(filterquery);
    const filterkeydata = filterkey.join("= ? AND ") + " = ?";
    ///////////////

    var result = Object.entries(filterquery);
    const rdata = result.join(" and ");
    const sdata = rdata.split(",");
    const equaldata = sdata.join(" = ");
    var values = [...abvalue, ...filtervalue];

    // abvalue.forEach()        // values.concat(abvalue);

    ///////////////
    connectDB.connect(function (err) {
      //   if (err) throw err;
      var sql = `UPDATE ${database_table_name} SET ${abkeydata} WHERE ${filterkeydata}`;
      connectDB.query(sql, values, function (err, result) {
        if (err) throw err;
        console.log(result.affectedRows + " record(s) updated");
        if (err) {
          reject(err);
        }
        resolved(result);
      });
    });
  });
};

module.exports.ASK_data = async () => {
  return await new Promise((resolved, reject) => {
    connectDB.query(
      "select at_price,base_order_value,quote_order_value from tbl_user_open_order_history where order_type_buy_sell=? order by at_price asc limit 10",
      ["SELL"],
      (err, response) => {
        if (err) throw err;
        else resolved(response);
      }
    );
  });
};

module.exports.BID_data = async () => {
  return await new Promise((resolved, reject) => {
    connectDB.query(
      "select at_price,base_order_value,quote_order_value from tbl_user_open_order_history where order_type_buy_sell=? order by at_price desc limit 10",
      ["BUY"],
      (err, response) => {
        if (err) throw err;
        else resolved(response);
      }
    );
  });
};

module.exports.Updated_offchain_withdrawal_data=async function(
  receiver_User_id,
  sender_user_id,
  receiver_updated_asset_volume,
  Receiver_new_avg_price,
  asset_volume,
  asset_id,
  receiver_XID,
  trxn_id,
  remarks
){
  return await new Promise(async (resolved, reject) => {
    connectDB.beginTransaction(function (err) {
      if (err) {
        throw err;
      }
      // Receiver Balance and avg price Update
      connectDB.query(
        "UPDATE tbl_user_crypto_assets_balance_details SET main_balance_btx =main_balance_btx + ? ,current_balance_btx = ?,avg_buy_price=?, d_by=?,last_updated_at=? WHERE cuser_id_btx = ? and asset_id_btx = ?",
        [asset_volume, receiver_updated_asset_volume,Receiver_new_avg_price,sender_user_id,Date.now(),receiver_User_id,asset_id],
        function (err, result) {
          if (err) {
            connectDB.rollback(function () {
              throw err;
            });
          } else {
            if (result.changedRows != 0) {
              // Update Sender Balance
              connectDB.query(
                "update tbl_user_crypto_assets_balance_details set main_balance_btx =main_balance_btx - ? ,current_balance_btx =current_balance_btx - ?,d_by=?,last_updated_at=? where cuser_id_btx=? and asset_id_btx=?",
                [
                  asset_volume,
                  asset_volume,
                  receiver_User_id,
                  Date.now(),
                  sender_user_id,
                  asset_id,
                ],
                function (err, result) {
                  if (err) {
                    connectDB.rollback(function () {
                      throw err;
                    });
                  } else if (result.changedRows != 0) {
                    connectDB.query(
                      "insert into tbl_user_crypto_withdrawal_trxn_details (cuser_id_btx,x_id_btx,wallet_id_btx,network,asset_id_btx,asset_amount_qty,to_address,remarks,trxn_id_btx,amount_recieved,trxn_fee,c_by) values (?,?,?,?,?,?,?,?,?,?,?,?)",
                      [
                        sender_user_id,receiver_XID,"user_cyrpto_wallet","Offchain",asset_id,asset_volume,receiver_XID,"offchain transferred ",trxn_id,'0','0',receiver_User_id
                      ],
                      (err, res) => {
                        if (err) {
                          connectDB.rollback(() => {
                            reject("err");
                            throw err;
                          });
                        } else if(res.affectedRows!=0){
                          connectDB.query(
                            "insert into tbl_user_crypto_deposit_trxn_details (cuser_id_btx,x_id_btx,user_wallet_id_btx,network,asset_id_btx,amount_recieved,trxn_date_time,from_address,to_address,current_status,trxn_id_btx,remarks,c_by) values (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            [
                              receiver_User_id,receiver_XID,"user_cyrpto_wallet","Offchain",asset_id,asset_volume,Date.now(),sender_user_id,receiver_XID,'1',trxn_id,remarks,sender_user_id
                            ],
                            (err,res)=>{
                              if (err) {
                                connectDB.rollback(() => {
                                  reject("err");
                                  throw err;
                                });
                              }else if(res.affectedRows!=0){
                                  connectDB.commit(()=>{
                                    resolved(res)
                                  })
                              }
                            })
                        }else{
                          connectDB.rollback();
                          reject('err');
                        }
                      }
                    );
                  }else{
                    connectDB.rollback();
                    reject('err');
                  }
                }
              );
            } else {
              connectDB.rollback();
              reject("err");
            }
          }
        }
      );
    });
  }).catch((e) => {
    connectDB.rollback();
    return e;
  });

}

module.exports.get_last_executed_rate = async (asset_id) => {
  return await new Promise((resolved, reject) => {
    connectDB.query(
      "select at_price from tbl_user_open_order_history where asset_id_btx=? order by id desc limit 1",
      [asset_id],
      (err, response) => {
        if (err) throw err;
        else resolved(response);
      }
    );
  });
};


// module.exports.Get_Where_Universal_Data = async (database_table_name, data) => {
//   return await new Promise(async (resolved, reject) => {
//     const connection = await getConnection(connectDB.pool);
//     {
//       await select("*")
//         .from(database_table_name)
//         .where(keyData, operator, valueData)
//         .execute(connection)
//         .then(async (res) => {
//           resolved(res);
//         })
//         .catch(async (e) => {
//           throw e;
//         });
//     }
//   });
// };

// module.exports.Update_Universal_Data = async ( database_table_name,updatedata) => {
//    return await new Promise(async (resolved, reject) => {
//      connectDB.connection.query("UPDATE `${database_table_name}` SET `isdeleted` = '1' WHERE `order_id` = ?",[order_id],(err,res)=>{
//        if(err) throw err
//        resolved (res)
//      })
//     });
//    };

// module.exports.Create_Universal_Data = async (database_table_name, data) => {
//   return await new Promise(async (resolved, reject) => {
//     const connection = await getConnection(connectDB.pool);
//     {
//       await insert(database_table_name)
//         .given(data)
//         .execute(connection)
//         .then(async (res) => {
//           // await commit(connection)
//           resolved(res);
//         })
//         .catch(async (e) => {
//           throw e;
//         });
//     }
//   });
// };

// module.exports.Create_Universal_Data = async ( user_id,quote_value_qty, asset_name)=>{

// connectDB.pool.getConnection(function(err, connection) {
//   connection.beginTransaction(function(err) {
//       if (err) {
//           connection.rollback(function() {
//               connection.release();
//           });
//       } else {
//           connection.query("select * from tbl_user_fiat_wallet_master where user_id =?",[user_id], function(err, results) {
//               if (err) {
//                   connection.rollback(function() {
//                       connection.release();
//                   });
//               } else {
//                  console.log("results", results)
//                   connection.commit(function(err) {
//                       if (err) {
//                           connection.rollback(function() {
//                               connection.release();
//                               //Failure
//                           });
//                       } else {
//                           connection.release();
//                           //Success
//                       }
//                   });
//               }
//           });
//       }
//   });
// });
// }

// module.exports.Create_Universal_Data = async (
//   user_id,
//   quote_value_qty,
//   asset_name
// ) => {
//   return await new Promise(async (resolved, reject) => {
//     connectDB.pool.getConnection().then((promiseConnection) => {
//       var conn = promiseConnection.connection;
//       conn.beginTransaction((err) => {
//         return conn.query("select * from tbl_user_fiat_wallet_master where user_id =?",[user_id],(err, res) => {
//             if (err) throw err;
//             else {
//               const current_balance = res.map((a) => a.current_balance);
//               const locked_balance = res.map((a) => a.locked_balance);
//               console.log("c",current_balance)
//               console.log("q",quote_value_qty)

//         return conn.query("UPDATE tbl_user_fiat_wallet_master SET locked_balance = ? current_balance=? WHERE id = ?",
//               [
//                 current_balance,
//                 locked_balance,
//                 user_id,
//               ],
//               async (err, res) => {
//                 if (err) {
//                   await conn.rollback();
//                   throw err
//                 } else {
//                   resolved(res);
//                   await conn.commit();
//                 }
//               }
//             );
//               if (current_balance > quote_value_qty) {

//                 const user_updated_locked_balance = locked_balance + quote_value_qty;
//                   console.log('user_updated_locked_balance',user_updated_locked_balance)

//                 const user_updated_current_balance = current_balance - quote_value_qty;
//                   console.log("user_updated_current_balance",user_updated_current_balance)
//                   console.log("kk")
//               }else{

//               }
//             }
//           }
//         );
//       });
//     }).catch((e)=>{
//          return e
//     });
//   });
// };

// module.exports.Create_Universal_Data = async (user_id ) => {
//     await  connectDB.con.beginTransaction(function (err,response) {
//          if (err) {
//            throw err;
//          }
//          const query1 = "select current_balance from tbl_user_fiat_wallet_master where user_id =?"
//          const values1 = [user_id]

//         return connectDB.con.query(query1,values1, function (err, result) {
//            if (err) {
//              connectDB.rollback();
//              throw err
//            }else{
//               const data = result
//               console.log(data)
//               response (result)
//            }
//         });
//         //  connectDB.con.commit(function (err) {
//         //   if (err) {
//         //     connectDB.rollback(function () {
//         //       throw err;
//         //     });
//         //   }
//         //   console.log("success!");
//         // });
//        });
//    // });
//  };

// module.exports.Get_Where_Universal_Data = async (database_table_name, keyData ,operator,valueData) => {
//   return await new Promise(async (resolved, reject) => {
//     const connection = await getConnection(connectDB.pool);
//     {
//       await select("*")
//         .from(database_table_name)
//         .where(keyData ,operator,valueData)
//         .execute(connection).then((res)=>{
//          resolved(res)
//       })
//          .catch(async(e)=>{
//          await rollback(connection)
//           throw e
//          })
//     }
//   });
// };

// module.exports.Update_Universal_Data = async ( database_table_name,updatedata,keyData ,operator,valueData) => {
//    return await new Promise(async (resolved, reject) => {
//       const connection = await getConnection(connectDB.pool);
//       await startTransaction(connection);
//       {
//          await update(database_table_name)
//          .given(updatedata)
//          .where(keyData ,operator,valueData)
//          .execute(connection).then(async(res)=>{
//             resolved(res)
//          })
//          .catch(async(e)=>{
//             await rollback(connection)
//             throw e});
//       }
//     });
//    };

//    // module.exports.Create_Universal_Data = async (database_table_name2,updatedata2,keyData2 ,operator2,valueData2,database_table_name3,updatedata3,keyData3 ,operator3,valueData3,database_table_name1, data1,) => {
//    //    // return await new Promise(async (resolved, reject) => {
//    //      const connection = await getConnection(connectDB.pool);
//    //      await startTransaction(connection);
//    //    try{
//    //       await update(database_table_name2)
//    //           .given(updatedata2)
//    //           .where(keyData2 ,operator2,valueData2)
//    //           .execute(connection)

//    //       await update(database_table_name3)
//    //           .given(updatedata3)
//    //           .where(keyData3 ,operator3,valueData3)
//    //           .execute(connection)

//    //       await insert(database_table_name1)
//    //           .given(data1)
//    //           .execute(connection)

//    //       await commit(connection)
//    //    }catch(e){
//    //       await rollback(connection)
//    //        throw e
//    //    }
//    //    // });
//    //  };

// //"tbl_user_open_order_history"
// //{user_id: "U2000", asset_id: "12121", asset_name: "ETH-INR", status: "1"}

// module.exports.Get_Where_Universal_Data = async (database_table_name, data) => {
//   return await new Promise((resolved, reject) => {
//     connectDB.dbConn.get_connection((qb) => {
//       qb.release();
//       qb.get_where(database_table_name, data, (err, response) => {
//         if (err) throw err;
//         resolved(response);
//       });
//     });
//   });
// };
// module.exports.Create_Universal_Data = async (database_table_name, data) => {
//   return await new Promise((resolved, reject) => {
//     connectDB.dbConn.get_connection((qb) => {
//       qb.release();
//       qb.insert(database_table_name, data, (err, response) => {
//         if (err) throw err;
//         resolved(response);
//       });
//     });
//   });
// };
// module.exports.Update_Universal_Data = async (
//   database_table_name,
//   updatedata,
//   filter_by
// ) => {
//   return await new Promise((resolved, reject) => {
//     connectDB.dbConn.get_connection((qb) => {
//       qb.release();
//       qb.update(database_table_name, updatedata, filter_by, (err, response) => {
//         if (err) {
//           throw err;
//         }
//         resolved(response);
//       });
//     });
//   });
// };

// //  module.exports.Update_Universal_Data=async()=>{

// //     return await new Promise((resolved, reject) => {
// //        connectDB.query("UPDATE tbl_user_open_order_history SET asset_name = 'commit25' WHERE id = 27",(err,res)=>{
// //             if(err) throw err
// //            resolved(res)
// //        })
// //     })
// // }
// // //insert into `tbl_user_open_order_history` (user_id , asset_name ) values ('u0001' , 'btc')

// // module.exports.Update_Universal=async()=>{
//     return await new Promise((resolved, reject) => {
//         const Query = "INSERT INTO tbl_user_fiat_wallet_master (id ,user_id , wallet_id ,main_balance,locked_balance ,current_balance,currency,last_updated_on ,status,c_by ,c_date,d_by , d_date) VALUES (id,'u00065', null ,null,null,null,null,null,null,null,null,null,null)"
//         connectDB.query(Query,(err,res)=>{
//             if(err) {throw err }
//             resolved(res)
//         })
//     })
// }

// *****************************************************************************

// const get_user_FiatData =await  new Promise((resolve, reject) => {
//    connectDB.query(query3,value3,function (err, result) {
//       if (err) throw err
//       resolve (result)
//    })
//  });

//  const locked_fund = get_user_FiatData.map(a=>a.locked_balance)
// // console.log(get_user_data)
// if(get_user_data){
// const get_admin_data = await  new Promise((resolve, reject) => {
//    connectDB.query(query4,value4,function (err, result) {
//       if (err) throw err
//       resolve (result)
//    })
//  });
// }

// connectDB.beginTransaction(async function (err) {
//   if (err) throw err;

//   var update_user = connectDB.query(query1, function (err, result) {
//     if (err) {
//       connectDB.rollback(function () {
//          throw err;
//        });
//     }
// });

//   if (update_user) {
//    var update_admin =  connectDB.query(query2, function (err, result) {
//       if (err) {
//         connectDB.rollback(function () {
//           throw err;
//         });
//       } else {
//         connectDB.commit(function (err) {
//           if (err) {
//             connectDB.rollback(function () {
//               throw err;
//             });
//           }
//           console.log("success!");
//         });
//       }
//     });
//   }
// });

// *****************************************************************************

// connectDB.beginTransaction(function(err) {
//    if (err) {
//        throw err;
//    }
//    connectDB.query(query1, function(err, result) {
//            if (err) {
//                connectDB.rollback(function() {
//                    throw err;
//                });
//            }else{
//                console.log('success!');                               //DONEEEEEEEEE

//            }
//            });
//    connectDB.query(query2, function(err, result) {
//            if (err) {
//                connectDB.rollback(function() {
//                    throw err;
//                });
//            }else{
//             connectDB.commit(function(err) {
//                if (err) {
//                  connectDB.rollback(function() {
//                    throw err;
//                  });
//                }
//                console.log('success!');
//              });
//            }
//            });

// });
