const {
  insert,
  getConnection,
  startTransaction,
  commit,
  rollback,
  update,
} = require("@nodejscart/mysql-query-builder");
const con = require("../DBCon/DBConnection");
const db = require("../DOA/DBQuery");
require("dotenv").config();

// Start a transaction
const user_data = async () => {
  const connection = await getConnection(con.pool);
  await startTransaction(connection);
  try {
    await db.Get_Where_Universal_Data("tbl_user_open_order_history", {
      user_id: "U2002",
      asset_id: "12121",
      asset_name: "ETH-INR",
      status: "1",
    });
    //   await commit(connection)
    await update("tbl_user_open_order_history")
      .given({ order_type_buy_sell: "SEll", at_price: "45000" })
      .where("user_id", "=", "U2000")
      .execute(connection);
    await commit(connection);
  } catch (e) {
    await rollback(connection);
    throw e;
  }
};
const new_d = async () => {
  await user_data();
  console.log("Inserted");
};
// new_d()

// module.exports.BuyAssetWithFiat = async (req, res) => {
//   try {
//     const {
//       user_id,
//       asset_pair,
//       base_value_qty,
//       quote_value_qty,
//       at_price_rate,
//       quote_currency,
//       c_by,
//       order_type,
//     } = req.body;

//     if (!user_id) {
//       return res.status(process.env.HTTP_BAD_REQ).send({
//         status: false,
//         msg: "user-id Required..!!",
//       });
//     }

//     if (!asset_pair) {
//       return res.status(process.env.HTTP_BAD_REQ).send({
//         status: false,
//         msg: "asset pair Required..!!",
//       });
//     }

//     if (!base_value_qty) {
//       return res.status(process.env.HTTP_BAD_REQ).send({
//         status: false,
//         msg: "Base asset Required..!!",
//       });
//     }

//     if (!quote_value_qty) {
//       return res.status(process.env.HTTP_BAD_REQ).send({
//         status: false,
//         msg: "Quote asset Required..!!",
//       });
//     }

//     const User_data = await db.Get_Where_Universal_Data(
//       process.env.tbl_u_fiat_m,
//       "user_id",
//       "=",
//       user_id
//     );

//     const User_INR_bal = User_data.map((a) => a.current_balance);
//     const User_locked_balance = User_data.map((a) => a.locked_balance);

//     // CHECK USER FIAT BALANCE & Then Check Admin Asset Balance........!!!

//     if (JSON.parse(User_INR_bal) > quote_value_qty) {
//       const Admin_data = await db.Get_Where_Universal_Data(
//         process.env.tbl_a_asset_m,
//         "asset_name",
//         "=",
//         asset_pair
//       );

//       // Fetching All Data from DB and Storing In Variable
//       const Admin_balance = Admin_data.map((a) => a.current_balance);
//       const Admin_asset_locked_bal = Admin_data.map((a) => a.locked_balance);
//       const Admin_updated_locked_asset =
//         JSON.parse(Admin_asset_locked_bal) + JSON.parse(base_value_qty);
//       const Admin_updated_current_bal = Admin_balance - base_value_qty;

//       const User_updated_locked_bal =
//         JSON.parse(User_locked_balance) + JSON.parse(quote_value_qty);

//       // CHECK ADMIN ASSET BALANCE
//       console.log(Admin_balance);
//       console.log(base_value_qty);
//       if (Admin_balance > base_value_qty) {
//         // ready to place order - 1) lock Fiat of user 2) lock asset of Admin 3) Place (Insert) order in open order history

//         await db.Create_Universal_Data(
//           process.env.tbl_u_fiat_m,
//           {
//             locked_balance: User_updated_locked_bal,
//             current_balance: User_INR_bal - quote_value_qty,
//           },
//           "user_id",
//           "=",
//           user_id,
//           process.env.tbl_a_asset_m,
//           {
//             loocked_balance: Admin_updated_locked_asset,
//             current_balance: Admin_updated_current_bal,
//           },
//           "asset_name",
//           "=",
//           asset_pair,
//           process.env.tbl_u_open_order,
//           {
//             user_id: user_id,
//             order_id: Date.now(),
//             asset_name: asset_pair,
//             order_type_Buy_Sell: "Buy",
//             order_type_Market_Limit: order_type,
//             quote_order_value: quote_value_qty,
//             base_order_value: base_value_qty,
//             at_price: at_price_rate,
//             order_placed_at: Date.now(),
//             c_by: c_by,
//             c_date: Date.now(),
//           }
//         );

//         const Data = {
//           user_id: user_id,
//           order_id: Date.now(),
//           asset_name: asset_pair,
//           base_value: base_value_qty,
//           quote_value: quote_value_qty,
//           buying_rate: at_price_rate,
//         };

//         return res.status(201).send({
//           status: 201,
//           Data: [Data],
//           msg: "Buy Order Placed Successfully..!!",
//         });
//       } else {
//         return res.status(400).send({
//           status: 400,
//           msg: "Currently Buying " + asset_pair + " not Available..!!",
//         });
//       }
//     } else {
//       return res.status(400).send({
//         status: 400,
//         msg: "Insufficient User Fiat balance...!!",
//       });
//     }
//   } catch (err) {
//     return res.status(500).send({
//       msg: err.message,
//     });
//   }
// };
