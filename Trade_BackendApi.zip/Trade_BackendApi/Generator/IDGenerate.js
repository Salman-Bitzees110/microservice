const GenerateUniqueID = (count, string, prefix) => {
    var str = "";
    for (var i = 0; i < count; i++) {
      if (string[i] != "-") {
        str += string[i];
      }
    }
    return prefix + str;
  };

  module.exports.GenerateID = GenerateUniqueID