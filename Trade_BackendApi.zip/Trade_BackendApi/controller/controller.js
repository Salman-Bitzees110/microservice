require("dotenv").config();
const db = require("../DOA/DBQuery");
const uuid = require("uuid");
const GenerateID = require("../Generator/IDGenerate");
const { use } = require("../routes/router");
const digioceans = require("../uploadFile/digiOcean");

module.exports.BuyAssetWithFiat = async (req, res) => {
  // Process - 1) Check user Fiat balance 2) Lock user fiat balance 3)Insert order into open orders
  try {
    const {
      user_id,
      asset_id,
      base_value_qty,
      quote_value_qty,
      at_price_rate,
      c_by,
      order_type,
      currency,
    } = req.body;

    // Sanitise All Input fields
    if (!user_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }

    if (!asset_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "asset pair Required..!!",
      });
    }

    if (!base_value_qty) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Base asset Required..!!",
      });
    }
    if (!quote_value_qty) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Quote asset Required..!!",
      });
    }
    if (!at_price_rate) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "market price Required..!!",
      });
    }
    if (!currency) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Fiat currency Required..!!",
      });
    }
    // Generating Unique Order_id for each order..
    const order_id = GenerateID.GenerateID(10, uuid.v1(), "PO").toUpperCase();

    // DataBase call to Start mysql transaction to get user data and update balance of User.
    const DataUpdated = await db.Create_Update_Buy_order_data(
      user_id,
      order_id,
      asset_id,
      "BUY",
      order_type,
      quote_value_qty,
      base_value_qty,
      at_price_rate,
      Date.now(),
      c_by,
      currency
    );
    if (DataUpdated == "No Data") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "User Not Found, Invalid Request..!!",
      });
    } else if (DataUpdated == "Insufficient Fund") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Insufficient user Fiat Balance..!!",
      });
    } else {
      const Data = {
        user_id: user_id,
        order_id: order_id,
        asset_name: asset_id,
        base_value: base_value_qty,
        quote_value: quote_value_qty,
        buying_rate: at_price_rate,
      };

      // After Orer Successfully Placing Sending Proper Response
      return res.status(process.env.HTTP_DATA_CREATED).send({
        status_code: 201,
        status: true,
        Data: [Data],
        msg: "ok.Buy Order Placed Successfully..!!",
      });
    }
  } catch (err) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: err.message,
    });
  }
};

module.exports.Sell_Holding_asset = async (req, res) => {
  // Process - 1) check user asset balance 2) lock user asset 3) insert order in open
  try {
    const {
      user_id,
      asset_id,
      currency,
      base_value_qty,
      quote_value_qty,
      at_price_rate,
      order_type,
      c_by,
    } = req.body;

    // Sanitise all Input fields
    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!asset_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Asset Pair Required..!!",
      });
    }
    if (!base_value_qty) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Base Value Required..!!",
      });
    }
    if (!quote_value_qty) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Quotee value Required..!!",
      });
    }
    if (!order_type) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "order type Required..!!",
      });
    }
    if (!at_price_rate) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Base Value Required..!!",
      });
    }
    if (!currency) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Quote currency Required..!!",
      });
    }

    // Generate Unique order id for each order
    const order_id = GenerateID.GenerateID(10, uuid.v1(), "SO").toUpperCase();

    // DataBase call to Start mysql transaction to get user data and update balance of User.
    const DataUpdated = await db.Create_update_Sell_order_Data(
      user_id,
      order_id,
      asset_id,
      currency,
      "SELL",
      order_type,
      quote_value_qty,
      base_value_qty,
      at_price_rate,
      Date.now(),
      c_by
    );
    if (DataUpdated == "No Data") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "User Not Found, Invalid Request..!!",
      });
    } else if (DataUpdated === "Insufficient Fund") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Insufficient user Asset Balance..!!",
      });
    } else {
      const Data = {
        user_id: user_id,
        order_id: order_id,
        asset_name: asset_id,
        base_value: base_value_qty,
        quote_value: quote_value_qty,
        buying_rate: at_price_rate,
      };
      // After Orer Successfully Placing Sending Proper Response
      return res.status(process.env.HTTP_DATA_CREATED).send({
        status_code: 201,
        status: true,
        Data: [Data],
        msg: "Sell Order Placed Successfully..!!",
      });
    }
  } catch (err) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: err.message,
    });
  }
};

module.exports.cancel_order = async (req, res) => {
  try {
    const { user_id, order_id } = req.body;

    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!order_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "order-id Required..!!",
      });
    }
    // get Order details from Open orders table
    const order_Data = await db.Get_Where_Universal_Data(
      "*",
      "tbl_user_open_order_history",
      { cuser_id_btx: user_id, order_id_btx: order_id, is_deleted: "0" }
    );
    // Check order Cancellation status
    if (!order_Data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Order Already cancelled..!!",
      });
    } else {
      const order_type = order_Data.map((a) => a.order_type_buy_sell);
      const asset_id = order_Data.map((a) => a.asset_id_btx);
      const quote_order_value = order_Data.map((a) => a.quote_order_value);
      const base_order_value = order_Data.map((a) => a.base_order_value);
      const currency = order_Data.map((a) => a.quote_currency_btx);
      const order_type_market_limit = order_Data.map(
        (a) => a.order_type_market_limit
      );

      if (order_type == "BUY") {
        // 1) Update tbl_open_orders is_deleted:true ,2) update balance of user
        const database_updated = await db.cancel_buy_order(
          user_id,
          order_id,
          asset_id,
          currency,
          order_type,
          order_type_market_limit,
          base_order_value,
          quote_order_value,
          Date.now()
        );
        // After succesffull database updation for send response message and data
        if (database_updated.affectedRows != 0) {
          return res.status(200).send({
            status: 200,
            msg: "Buy Order canceled " + asset_id,
          });
        }
        // for Sell order processs
      } else if (order_type == "SELL") {
        // 1) Update tbl_open_orders is_deleted:true ,2) update balance of user
        const database_updated = await db.cancel_sell_order(
          user_id,
          order_id,
          asset_id,
          currency,
          order_type,
          order_type_market_limit,
          base_order_value,
          quote_order_value,
          Date.now()
        );
        // After succesffull database updation for send response message and data
        if (database_updated.affectedRows != 0) {
          return res.status(400).send({
            status: 400,
            msg: "Sell Order canceled " + asset_id,
          });
        }
      }
    }
  } catch (e) {
    res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      stauts: false,
      msg: e.message,
    });
  }
};

module.exports.Modify_order = async (req, res) => {
  try {
    // process - 1)get all data 2)get open-order details 3)if BUY order = Check fiat balance 4)Cancel current BUY order 5) place new BUY order
    //             6) if SELL order = Check crypto balance 7)cancel current sell order 8)Place new SELL order

    const {
      user_id,
      order_id,
      asset_id,
      base_value_qty,
      quote_value_qty,
      at_price_rate,
      order_type,
      currency,
    } = req.body;

    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }

    if (!order_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "order-id Required..!!",
      });
    }

    // Get order details from open order history table
    const order_Data = await db.Get_Where_Universal_Data(
      "*",
      "tbl_user_open_order_history",
      { cuser_id_btx: user_id, order_id_btx: order_id, is_deleted: "0" }
    );

    // Check order cancellation status
    if (!order_Data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Order Already cancelled..!!",
      });
    } else {
      //if order is not canceled before cancel last order and process for new order.
      const current_order_type = order_Data.map((a) => a.order_type_buy_sell);
      const current_quote_order_value = order_Data.map(
        (a) => a.quote_order_value
      );
      const current_base_order_value = order_Data.map(
        (a) => a.base_order_value
      );
      const current_currency = order_Data.map((a) => a.quote_currency_btx);
      const current_order_type_market_limit = order_Data.map(
        (a) => a.order_type_market_limit
      );
      // Check if the order is buy
      if (current_order_type == "BUY") {
        const user_fiat_balance = await db.Get_Where_Universal_Data(
          "current_balance_btx",
          "tbl_user_fiat_wallet_master",
          { cuser_id_btx: user_id, currency_btx: currency }
        );
        const User_fiat_balance = user_fiat_balance.map(
          (a) => a.current_balance_btx
        );
        if (JSON.parse(User_fiat_balance) >= quote_value_qty) {
          // 1) Update tbl_open_orders is_deleted:true ,2) update balance of user
          const DataUpdated = await db.cancel_buy_order(
            user_id,
            order_id,
            asset_id,
            current_currency,
            current_order_type,
            current_order_type_market_limit,
            current_base_order_value,
            current_quote_order_value,
            Date.now()
          );
          // Placing New order
          if (DataUpdated.affectedRows != 0) {
            this.BuyAssetWithFiat(req, res);
          }
        } else {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: "Insufficient User fiat Balance..!!",
          });
        }
        // Check if the order is sell
      } else if (current_order_type == "SELL") {
        // Get Balance data of user
        const user_asset_bal = await db.Get_Where_Universal_Data(
          "current_balance_btx",
          "tbl_user_crypto_assets_balance_details",
          { cuser_id_btx: user_id, asset_id_btx: asset_id }
        );
        const User_asset_bal = user_asset_bal.map((a) => a.current_balance_btx);

        // Check if user have sufficient fund for transaction.
        if (JSON.parse(User_asset_bal) >= base_value_qty) {
          // 1) Update tbl_open_orders is_deleted:true ,2) update balance of user
          const DataUpdated = await db.cancel_sell_order(
            user_id,
            order_id,
            asset_id,
            current_currency,
            current_order_type,
            current_order_type_market_limit,
            current_base_order_value,
            current_quote_order_value,
            Date.now()
          );
          if (DataUpdated == "err") {
            return res.status(process.env.HTTP_BAD_REQ).send({
              status_code: 400,
              status: false,
              msg: "Something went wrong..!!",
            });
          } else if (DataUpdated.affectedRows != 0) {
            this.Sell_Holding_asset(req, res);
          } else {
            return res.status(process.env.HTTP_BAD_REQ).send({
              status_code: 400,
              status: false,
              msg: "Something went wrong..!!",
            });
          }
        } else {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: "Insufficient User Asset Balance..!!",
          });
        }
      }
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.swap_asset = async (req, res) => {
  try {
    // Data required from api.
    const {
      user_id,
      pair_id,
      base_asset_id,
      quote_asset_id,
      quote_asset_volume,
      base_market_price,
      quote_market_price,
    } = req.body;

    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!pair_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "pair-id Required..!!",
      });
    }
    if (!base_asset_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "base asset-id Required..!!",
      });
    }
    if (!quote_asset_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "quote assetid Required..!!",
      });
    }
    if (!quote_asset_volume) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "quote asset value Required..!!",
      });
    }
    if (!quote_market_price) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "quote market price Required..!!",
      });
    }
    if (!base_market_price) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "base market price Required..!!",
      });
    }

    const asset_availability = await db.Get_Where_Universal_Data(
      "pair_name_btx",
      "tbl_registered_asset_pair_master",
      { pair_id_btx: pair_id }
    );

    if (asset_availability.length) {
      // const quote_asset_value = base_asset_value * quote_market_price;
      const base_asset_volume =
        (quote_asset_volume * quote_market_price) / base_market_price;

      const effective_base_value =
        base_asset_volume - (0.02 * base_asset_volume) / 100;
      const swap_fee = (0.02 * base_asset_volume) / 100;

      const user_quote_asset = await db.Get_Where_Universal_Data(
        "current_balance_btx",
        "tbl_user_crypto_assets_balance_details",
        { asset_id_btx: quote_asset_id, cuser_id_btx: user_id }
      );
      if (!user_quote_asset.length) {
        return res.status(400).send({
          status_code: 400,
          status: false,
          msg: "user quote data not found ..!!",
        });
      }
      const user_quote_bal = user_quote_asset.map((a) => a.current_balance_btx);

      // Check User quote asset balance
      if (JSON.parse(user_quote_bal) >= quote_asset_volume) {
        // Get admin quote data to check balance
        const admin_quote_balance = await db.Get_Where_Universal_Data(
          "current_balance_btz",
          "tbl_admin_crypto_wallet_master",
          { asset_id_btz: base_asset_id }
        );
        if (!admin_quote_balance.length) {
          return res.status(400).send({
            status_code: 400,
            status: false,
            msg: "Currently swap not available..!!",
          });
        }

        const admin_asset_bal = admin_quote_balance.map(
          (a) => a.current_balance_btz
        );

        // Check admin quote balance
        if (JSON.parse(admin_asset_bal) >= effective_base_value) {
          const swap_order_id = GenerateID.GenerateID(
            7,
            uuid.v1(),
            "SW"
          ).toUpperCase();

          // (BTC-ETH)
          // Update user & admin crypto data 1) Debit base asset from user_tbl 2)Credit base asset to admin tbl  3)debit admin quote asset - swap fee
          //    4) credit user quote asset  - swap fee   5) add swap fee details in swap_fee table 6)add swap trxn in tbl_swap_trxn_details
          const DataUpdated = await db.Update_swap_data(
            user_id,
            base_asset_volume,
            effective_base_value,
            base_asset_id,
            quote_asset_id,
            swap_order_id,
            swap_fee,
            quote_asset_volume,
            Date.now()
          );

          if (DataUpdated.affectedRows != 0) {
            return res.status(process.env.HTTP_OK).send({
              status_code: 200,
              status: false,
              Data: [
                {
                  swap_order_id: swap_order_id,
                  paid_base_asset: base_asset_volume,
                  received_asset: effective_base_value,
                  fee_paid: swap_fee,
                },
              ],
              msg: "Swap Successfull..!!",
            });
          }
        } else {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: "Currently Swap not available..!!",
          });
        }
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: "Insufficient user quote asset balance.!!",
        });
      }
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Swapping pair not available..!!",
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.P2P_Buy = async (req, res) => {
  try {
    const { user_id, asset_id, asset_rate, asset_volume, XID, fiat_rate } =
      req.body;

    if (!asset_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "base asset-id Required..!!",
      });
    }
    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!asset_rate) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "rate Required..!!",
      });
    }
    if (!asset_volume) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "asset qty Required..!!",
      });
    }
    if (!fiat_rate) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "fiat rate Required..!!",
      });
    }

    const registered_asset = await db.Get_Where_Universal_Data(
      "asset_id_btx",
      "tbl_asset_master",
      { asset_id_btx: asset_id }
    );

    if (!registered_asset.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Asset not available..!!",
      });
    }
    const order_id = GenerateID.GenerateID(7, uuid.v1(), "PB").toUpperCase();

    const DataUpdated = await db.Create_Universal_Data(
      "tbl_user_p2p_open_order_history",
      {
        cuser_id_btx: user_id,
        order_id_btx: order_id,
        asset_id_btx: asset_id,
        asset_rate: asset_rate,
        asset_volume: asset_volume,
        fiat_rate: fiat_rate,
        XID: XID,
        order_type_buy_sell: "BUY",
        order_placed_at: Date.now(),
        c_by: user_id,
      }
    );

    if (DataUpdated.affectedRows != 0) {
      return res.status(process.env.HTTP_OK).send({
        status_code: 200,
        status: true,
        data: [
          {
            user_id: user_id,
            asset_id: asset_id,
            asset_rate: asset_rate,
            asset_volume: asset_volume,
            XID: XID,
            fiat_rate: fiat_rate,
          },
        ],
        msg: `P2P BUY order Placed. Order_ID: ${order_id}..!!`,
      });
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Something went wrong..!!!`,
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.P2P_Sell = async (req, res) => {
  try {
    const { user_id, asset_id, rate_fiat, asset_volume, XID, total_fiat } =
      req.body;

    if (!asset_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "base asset-id Required..!!",
      });
    }
    if (!user_id) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!rate_fiat) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "rate Required..!!",
      });
    }
    if (!asset_volume) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "asset qty Required..!!",
      });
    }
    if (!total_fiat) {
      return res.status(400).send({
        status_code: 400,
        status: false,
        msg: "fiat rate Required..!!",
      });
    }

    const order_id = GenerateID.GenerateID(7, uuid.v1(), "PB").toUpperCase();

    const DataUpdated = await db.Update_data_P2P_sell_asset(
      user_id,
      order_id,
      asset_id,
      rate_fiat,
      asset_volume,
      total_fiat,
      XID,
      "SELL",
      Date.now(),
      user_id
    );
    if (DataUpdated == "Insufficient Fund") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Insufficient user Asset..!!`,
      });
    } else if (DataUpdated == "No Data") {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Something went wrong..!!`,
      });
    } else if (DataUpdated == "DataBase Updated") {
      return res.status(process.env.HTTP_OK).send({
        status_code: 200,
        status: true,
        data: [
          {
            user_id: user_id,
            asset_id: asset_id,
            asset_rate: rate_fiat,
            asset_volume: asset_volume,
            XID: XID,
            fiat_rate: total_fiat,
          },
        ],
        msg: `P2P Sell order Placed. Order_ID: ${order_id}..!!`,
      });
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Something went wrong..!!`,
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.P2P_cancel_order = async (req, res) => {
  try {
    const { user_id, order_id } = req.body;
    if (!user_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "user-id Required..!!",
      });
    }
    if (!order_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "order-id Required..!!",
      });
    }

    const order_data = await db.Get_Where_Universal_Data(
      "*",
      "tbl_user_p2p_open_order_history",
      { cuser_id_btx: user_id, order_id_btx: order_id, is_deleted: "0" }
    );

    if (!order_data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Order Already canceled, Order-id: ${order_id}..!!`,
      });
    }
    if (order_data.length) {
      const order_type = order_data.map((a) => a.order_type_buy_sell);
      const asset_id = order_data.map((a) => a.asset_id_btx);
      const asset_rate = order_data.map((a) => a.asset_rate);
      const asset_volume = order_data.map((a) => a.asset_volume);
      const fiat_rate = order_data.map((a) => a.fiat_rate);
      const XID = order_data.map((a) => a.XID);

      const data_updated = await db.Cancel_P2P_BUY_order(
        user_id,
        order_id,
        asset_id,
        asset_rate,
        asset_volume,
        fiat_rate,
        XID,
        order_type,
        Date.now(),
        user_id
      );

      if (data_updated.affectedRows != 0) {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 200,
          status: true,
          msg: `Order canceled successfully, Order-id: ${order_id}..!!`,
        });
      }

      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Something went wrong, Order-id: ${order_id}..!!`,
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.Dummy_executed_order = async (req, res) => {
  try {
    const {
      user_id,
      order_id,
      base_asset_id,
      quote_asset_id,
      order_type_buy_sell,
      order_type_ml,
      base_order_value,
      quote_order_value,
      at_rate_price,
    } = req.body;

    const dataUpdated = await db.Create_Universal_Data(
      " tbl_user_executed_order_history",
      {
        cuser_id_btx: user_id,
        order_id: order_id,
        base_asset_id_btx: base_asset_id,
        quote_asset_id_btx: quote_asset_id,
        order_type_buy_sell: order_type_buy_sell,
        order_type_market_limit: order_type_ml,
        base_order_value: base_order_value,
        quote_order_value: quote_order_value,
        at_rate: at_rate_price,
        order_executed_at: Date.now(),
      }
    );
    if (dataUpdated) {
      return res.send(dataUpdated);
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.ASK_order_data = async (req, res) => {
  try {
    const data = await db.ASK_data();
    if (data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 200,
        status: true,
        msg: `Best sell orders list , ASK ORDERS DATA `,
        Data: [data],
      });
    } else if (!data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `No data received..!!`,
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.BID_order_data = async (req, res) => {
  try {
    const data = await db.BID_data();
    if (data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 200,
        status: true,
        msg: `Best BUY orders list , BID ORDERS DATA `,
        Data: [data],
      });
    } else if (!data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `No data received..!!`,
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.Get_executed_orders = async (req, res) => {
  try {
    const user_id = req.query.user_id;

    if (user_id) {
      const data = await db.Get_Where_Universal_Data(
        "order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_executed_at",
        "tbl_user_executed_order_history",
        { cuser_id_btx: user_id }
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `Executed orders of ${user_id} ..!!`,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: `NO executed orders of ${user_id} ..!!`,
          Data: [],
        });
      }
    } else if (!user_id) {
      const data = await db.Get_All_Universal_Data(
        "order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_executed_at",
        "tbl_user_executed_order_history"
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `Executed orders of all user.!! `,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: "something went wrong..!!",
        });
      }
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.Get_open_orders = async (req, res) => {
  try {
    const user_id = req.query.user_id;

    if (user_id) {
      const data = await db.Get_Where_Universal_Data(
        "cuser_id_btx,order_id_btx,asset_id_btx,quote_currency_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_placed_at",
        "tbl_user_open_order_history",
        { cuser_id_btx: user_id }
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `Open orders of ${user_id} ..!!`,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: `NO Open orders of ${user_id} ..!!`,
          Data: [],
        });
      }
    } else if (!user_id) {
      const data = await db.Get_All_Universal_Data(
        "cuser_id_btx,order_id_btx,asset_id_btx,quote_currency_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_placed_at",
        "tbl_user_open_order_history"
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `Open orders of all user.!! `,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: "something went wrong..!!",
        });
      }
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.Get_cancel_orders = async (req, res) => {
  try {
    const user_id = req.query.user_id;

    if (user_id) {
      const data = await db.Get_Where_Universal_Data(
        "order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_cancelled_at",
        "tbl_user_cancelled_order_history",
        { cuser_id_btx: user_id }
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `cancel orders of ${user_id} ..!!`,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: `NO Cancel orders of ${user_id} ..!!`,
          Data: [],
        });
      }
    } else if (!user_id) {
      const data = await db.Get_All_Universal_Data(
        "cuser_id_btx,order_id,base_asset_id_btx,quote_asset_id_btx,order_type_buy_sell,order_type_market_limit,base_order_value,quote_order_value,order_cancelled_at",
        "tbl_user_cancelled_order_history"
      );
      if (data.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `Cancel orders of all user.!! `,
          Data: [data],
        });
      } else {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: "something went wrong..!!",
        });
      }
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.P2P_upload_payment_details = async (req, res) => {
  try {
    const { user_id, order_id, order_type, payment_trxn_id, paid_amount } =
      req.body;

    const files = req.files;
    if (!user_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `user-id required. `,
        Data: [],
      });
    }
    if (!order_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `order-id required. `,
        Data: [],
      });
    }
    if (!order_type) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `order-type required. `,
        Data: [],
      });
    }
    if (!payment_trxn_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `payment trxn-id required. `,
        Data: [],
      });
    }
    if (!paid_amount) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `paid amount required. `,
        Data: [],
      });
    }
    if (!(files && files.length > 0)) {
      return res
        .status(process.env.HTTP_BAD_REQ)
        .send({ status_code: 400, status: false, message: "No file found" });
    }

    const check_order = await db.Get_Where_Universal_Data(
      "*",
      "tbl_p2p_payment_details",
      { order_id_btx: order_id }
    );

    if (check_order.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Payment details already uploaded. `,
        Data: [],
      });
    }

    if (files[0].fieldname === "p2p_screenshot") {
      const p2p_screenshot = digioceans.Upload(
        "p2p_payment_deposite/",
        user_id,
        "p2p",
        files[0]
      );

      const data = await db.Create_Universal_Data("tbl_p2p_payment_details", {
        cuser_id_btx: user_id,
        order_id_btx: order_id,
        order_type: order_type,
        payment_ss_url: p2p_screenshot,
        payment_trxn_id: payment_trxn_id,
        paid_amount: paid_amount,
        trxn_at: Date.now(),
        c_by: user_id,
      });
      if (data.affectedRows != 0) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          data: [
            {
              user_id: user_id,
              order_id: order_id,
              payment_url: p2p_screenshot,
              payment_id: payment_trxn_id,
            },
          ],
          msg: "Payment details submitted",
        });
      }
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: "Pan Image Required..1234!!",
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.get_payment_details_p2p = async (req, res) => {
  try {
    const { order_id } = req.body;

    if (!order_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: true,
        msg: `order-id required. `,
        Data: [],
      });
    }

    const data = await db.Get_Where_Universal_Data(
      "cuser_id_btx,order_id_btx,payment_ss_url,payment_trxn_id,paid_amount,trxn_at",
      "tbl_p2p_payment_details",
      { order_id_btx: order_id }
    );
    if (data.length) {
      const p2p_screenshot = data.map((a) => a.payment_ss_url);
      const payment_trxn_id = data.map((a) => a.payment_trxn_id);
      const payment_time = data.map((a) => a.trxn_at);
      const paid_amount = data.map((a) => a.paid_amount);
      const user_id = data.map((a) => a.cuser_id_btx);

      return res.status(process.env.HTTP_OK).send({
        status_code: 200,
        status: true,
        data: [
          {
            "user-id": user_id,
            "order-id": order_id,
            "payment-url": p2p_screenshot,
            "payment trxn-id": payment_trxn_id,
            "Paid Amount": paid_amount,
            "trxn time": payment_time,
          },
        ],
        msg: "Payment details submitted",
      });
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: true,
        msg: `No payment record`,
        Data: [data],
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.P2P_payment_received_approved = async (req, res) => {
  try {
    const { order_id } = req.body;

    if (!order_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `order-id required. `,
        Data: [],
      });
    }

    const receiver_data = await db.Get_Where_Universal_Data(
      "cuser_id_btx,payment_ss_url,paid_amount",
      "tbl_p2p_payment_details",
      { order_id_btx: order_id }
    );

    if (!receiver_data.length) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `No payment received for this order `,
        Data: [],
      });
    }

    const p2p_fee_data = await db.Get_Where_Universal_Data(
      "fee_amount",
      "tbl_fixed_fee_details",
      { fee_type: "p2p_buy" }
    );

    const data = await db.Get_Where_Universal_Data(
      "cuser_id_btx,asset_id_btx,asset_volume",
      "tbl_user_p2p_open_order_history",
      { order_id_btx: order_id }
    );

    if (data.length) {
      const user_id = data.map((a) => a.cuser_id_btx);
      const asset_id = data.map((a) => a.asset_id_btx);
      const asset_volume = data.map((a) => a.asset_volume);
      const receiver_user_id = receiver_data.map((a) => a.cuser_id_btx);
      const buyer_payment_ss = receiver_data.map((a) => a.payment_ss_url);
      const buyer_payment_amount = receiver_data.map((a) => a.paid_amount);
      const p2p_fee = p2p_fee_data.map((a) => a.fee_amount);

      const p2p_fee_received = (p2p_fee * asset_volume) / 100;
      const effective_receiver_volume = asset_volume - p2p_fee_received;

      const dataUpdated = await db.p2p_after_payment_verification_update(
        user_id,
        order_id,
        asset_id,
        asset_volume,
        receiver_user_id,
        effective_receiver_volume,
        p2p_fee_received,
        buyer_payment_ss,
        buyer_payment_amount
      );
      if (dataUpdated == "NO Data") {
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: `DB error `,
          Data: [],
        });
      } else if (dataUpdated.length) {
        return res.status(process.env.HTTP_OK).send({
          status_code: 200,
          status: true,
          msg: `P2P order successfully completed.!! `,
          Data: [],
        });
      }
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Order Already Approved.!! `,
        Data: [],
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.current_market_price = async (req, res) => {
  try {
    const { asset_id } = req.body;

    if (!asset_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `asset-id required. `,
        Data: [],
      });
    }

    const Last_executed_rate = await db.get_last_executed_rate(asset_id);
    const current_rate = Last_executed_rate.map((a) => a.at_price);

    if (Last_executed_rate.length) {
      return res.status(process.env.HTTP_OK).send({
        status_code: 200,
        status: true,
        data: [
          {
            "aasset id": asset_id,
            "Current market rate": current_rate,
          },
        ],
        msg: `Last Executed rate : ${current_rate}`,
      });
    } else {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `Something Went wrong. `,
        Data: [],
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};

module.exports.Offchain_Withdrawal = async (req, res) => {
  try {
    const {
      receiver_XID,
      sender_user_id,
      asset_id,
      asset_volume,
      asset_rate,
      remarks,
    } = req.body;

    if (!sender_user_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `user-id required.`,
        Data: [],
      });
    }
    if (!receiver_XID) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `XID required.`,
        Data: [],
      });
    }
    if (!asset_id) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `asset-id required.`,
        Data: [],
      });
    }
    if (!asset_volume) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `asset volume required.`,
        Data: [],
      });
    }
    if (!asset_rate) {
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `asset rate required.`,
        Data: [],
      });
    }

    const sender_balance = await db.Get_Where_Universal_Data(
      "current_balance_btx",
      "tbl_user_crypto_assets_balance_details",
      { cuser_id_btx: sender_user_id, asset_id_btx: asset_id }
    );
    if (sender_balance.length) {
      const balance = sender_balance.map((a) => a.current_balance_btx);
     
      if (asset_volume <= JSON.parse(balance)) {
        /// Get Receiver user id from XID
        const user_id_from_XID = await db.Get_Where_Universal_Data(
          "cuser_id_btx",
          "tbl_user_registration_master",
          { x_id_btx: receiver_XID }
        );
        if (!user_id_from_XID.length) {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: `Incorrect XID....!!!`,
            Data: [],
          });
        }
        const receiver_User_id = user_id_from_XID.map((a) => a.cuser_id_btx);

        // Get Receiver Holding asset Detials
        const get_receiver_holdings_detials = await db.Get_Where_Universal_Data(
          "current_balance_btx,avg_buy_price",
          "tbl_user_crypto_assets_balance_details",
          { cuser_id_btx: receiver_User_id, asset_id_btx: asset_id }
        );

        // Total Value of receiver current Holding before trxn
        const holding_asset_value =
          get_receiver_holdings_detials.map((a) => a.current_balance_btx) *
          get_receiver_holdings_detials.map((a) => a.avg_buy_price);

        // New order total Valuation
        const New_order_value = asset_volume * asset_rate;

        // Receiver Total Holding Qty (Volume) after Trxn of asset
        const receiver_updated_asset_volume =
          JSON.parse(
            get_receiver_holdings_detials.map((a) => a.current_balance_btx)
          ) + asset_volume;

        // Receiver total Holding Value after Trxn of asset
        const total_reciever_value = holding_asset_value + New_order_value;

        // Updated AveraGE price of receiver's asset
        const Receiver_new_avg_price =
          total_reciever_value / receiver_updated_asset_volume;

        // Gewnerate ndew transaction id for new order
        const trxn_id = GenerateID.GenerateID(
          7,
          uuid.v1(),
          "TRXN"
        ).toUpperCase();

        // MySql Transaction DB call for updating ledger of Sender and receiver Balance and update withdrtawal and deposit history table
        const updated_data = await db.Updated_offchain_withdrawal_data(
          receiver_User_id,
          sender_user_id,
          receiver_updated_asset_volume,
          Receiver_new_avg_price,
          asset_volume,
          asset_id,
          receiver_XID,
          trxn_id,
          remarks
        );

        // After Database Update successfulll send proper response to sender
        if (updated_data.affectedRows != 0) {
          return res.status(process.env.HTTP_OK).send({
            status_code: 200,
            status: true,
            msg: `Withdrawal Successful.!!!`,
            Data: [
              {
                "sender user-id": sender_user_id,
                "Receiver XID": receiver_XID,
                "Asset ID": asset_id,
                "asset Volume Transfered": asset_volume,
                "asset Rate": asset_rate,
                "Transaction-ID": trxn_id,
              },
            ],
          });

          // Send err response to userr
        } else if (updated_data == "err") {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: `Withdrawal Failed...!!`,
            Data: [],
          });
        } else {
          return res.status(process.env.HTTP_BAD_REQ).send({
            status_code: 400,
            status: false,
            msg: `Something went Wrong...!!`,
            Data: [],
          });
        }
      }else{
        return res.status(process.env.HTTP_BAD_REQ).send({
          status_code: 400,
          status: false,
          msg: `Insufficient ${sender_user_id} balance.`,
          Data: [],
        });
      }
    }else{
      return res.status(process.env.HTTP_BAD_REQ).send({
        status_code: 400,
        status: false,
        msg: `User not found..!!`,
        Data: [],
      });
    }
  } catch (e) {
    return res.status(process.env.HTTP_SERVER_ERROR).send({
      status_code: 500,
      status: false,
      msg: e.message,
    });
  }
};








// module.exports.test = async (req, res) => {
//   connectDB.beginTransaction();
//   const store = await db.Update_Universal_Data();
//   if (store) {
//     const store2 = await db.Update_Universal();
//     connectDB.commit();
//     if (!store2) {
//       connectDB.rollback();
//     } else {
//       return res.send(store2);
//     }
//   }
// };

// module.exports.BuyAssetWithFiat =async (req,res)=>{
//   try{
//      const {user_id, asset_pair ,  base_value_qty ,  quote_value_qty , at_price_rate , quote_currency, c_by, order_type} = req.body

//      if (!user_id) {
//         return res.status(process.env.HTTP_BAD_REQ).send({
//           status: false,
//           msg: "user-id Required..!!",
//         });
//       }

//       if (!asset_pair) {
//         return res.status(process.env.HTTP_BAD_REQ).send({
//           status: false,
//           msg: "asset pair Required..!!",
//         });
//       }

//       if (!base_value_qty) {
//         return res.status(process.env.HTTP_BAD_REQ).send({
//           status: false,
//           msg: "Base asset Required..!!",
//         });
//       }

//       if (!quote_value_qty) {
//         return res.status(process.env.HTTP_BAD_REQ).send({
//           status: false,
//           msg: "Quote asset Required..!!",
//         });
//       }

//      const User_data =await db.Get_Where_Universal_Data(process.env.tbl_u_fiat_m ,{user_id:user_id})

//      const User_INR_bal = User_data.map(a=>a.current_balance)
//      const User_locked_balance = User_data.map(a=>a.locked_balance)

//      // CHECK USER FIAT BALANCE & Then Check Admin Asset Balance........!!!
//     if(JSON.stringify(User_INR_bal) > quote_value_qty) {

//         const Admin_data =await db.Get_Where_Universal_Data(process.env.tbl_a_asset_m, {asset_name:asset_pair})

//        // Fetching All Data from DB and Storing In Variable
//         const Admin_balance = Admin_data.map(a=>a.current_balance)
//         const Admin_asset_locked_bal = Admin_data.map(a=>a.locked_balance)
//         const Admin_updated_locked_asset = JSON.parse(Admin_asset_locked_bal) + JSON.parse(base_value_qty)
//         const Admin_updated_current_bal = Admin_balance - base_value_qty

//         const User_updated_locked_bal = JSON.parse(User_locked_balance) + JSON.parse(quote_value_qty)
//         // CHECK ADMIN ASSET BALANCE
//         if(Admin_balance > base_value_qty){

//         // ready to place order - 1) lock Fiat of user 2) lock asset of Admin 3) Place (Insert) order in open order history

//         /* 1)*/ await db.Update_Universal_Data(process.env.tbl_u_fiat_m ,{locked_balance:User_updated_locked_bal, current_balance: User_INR_bal - quote_value_qty},{user_id:user_id})

//         /* 2)*/  await db.Update_Universal_Data(process.env.tbl_a_asset_m ,{loocked_balance:Admin_updated_locked_asset , current_balance:Admin_updated_current_bal} , {asset_name:asset_pair})

//         /* 3) */ await db.Create_Universal_Data(process.env.tbl_u_open_order,{user_id:user_id ,order_id:Date.now() , asset_name:asset_pair ,order_type_Buy_Sell: "Buy" ,order_type_Market_Limit:order_type , quote_order_value:quote_value_qty , base_order_value:base_value_qty,at_price:at_price_rate,status:"1",is_deleted:"0",order_placed_at:Date.now(),c_by:c_by,c_date:Date.now()})

//         const Data = {
//               user_id:user_id,
//               order_id:Date.now(),
//               asset_name:asset_pair,
//               base_value:base_value_qty,
//               quote_value:quote_value_qty,
//               buying_rate:at_price_rate
//             }

//             return res.status(201).send({
//             status: 201,
//             Data:[Data],
//             msg: "Buy Order Placed Successfully..!!",
//           });
//         }else{
//           return res.status(40).send({
//             status: 400,
//             Data:[Data],
//             msg: "Currently Buying " + asset_pair + " not Available..!!",
//           });
//         }
//     }else{
//       return res.status(400).send({
//           status: 400,
//           Data:[Data],
//           msg: "Insufficient User " + quote_value_qty + " balance...!!",
//         });
//     }
//   }catch(err){
//     return res.status(500).send({
//       msg: err.message,

//   })
//   }
// }
