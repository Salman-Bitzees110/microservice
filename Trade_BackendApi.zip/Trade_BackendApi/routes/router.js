const express = require('express');
const router = express.Router();
const userController = require('../controller/controller')


router.post('/buyOrderWithFiat',userController.BuyAssetWithFiat)
router.post('/sellHoldingAsset' , userController.Sell_Holding_asset)
router.post('/cancelOrder',userController.cancel_order)
router.post('/modifyOrder',userController.Modify_order)
router.post('/swap_asset',userController.swap_asset)
router.post('/P2PBuyOrder',userController.P2P_Buy)
router.post('/P2PSellOrder',userController.P2P_Sell)
router.post('/P2PCancelOrder',userController.P2P_cancel_order)
router.post('/Dummy_executed_order',userController.Dummy_executed_order)
router.post('/ask_data',userController.ASK_order_data)
router.post('/bid_data',userController.BID_order_data)
router.post('/get_executed_orders',userController.Get_executed_orders)
router.post('/get_open_orders',userController.Get_open_orders)
router.post('/get_cancel_orders',userController.Get_cancel_orders)
router.post('/upload_p2p_ss',userController.P2P_upload_payment_details)
router.post('/get_p2p_payment_details',userController.get_payment_details_p2p)
router.post('/P2P_payment_received_approved',userController.P2P_payment_received_approved)
router.post('/Offchain_asset_withdrawal',userController.Offchain_Withdrawal)
router.post('/asset_market_rate',userController.current_market_price)
module.exports = router