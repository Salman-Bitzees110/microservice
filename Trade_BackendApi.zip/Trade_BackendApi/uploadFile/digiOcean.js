const AWS = require("aws-sdk");
const fs = require("fs");
const dotenv = require("dotenv");
require('dotenv').config();
let DO_ENDPOINT = "https://nyc3.digitaloceanspaces.com/";
let DO_ACCESS_KEY_ID = "DO00GKDLH8CKM9MD7HEH";
let DO_SECRET_ACCESS_KEY = "J7IOYKzJbZqAjjh/PKVG1pWilCUDrtRwz8lZuz8sjrU";
var DO_SPACE = "bitzees";
// Create an S3 clientvar
 s3 = new AWS.S3({
    endpoint: DO_ENDPOINT, 
    accessKeyId: DO_ACCESS_KEY_ID, 
    secretAccessKey: DO_SECRET_ACCESS_KEY
});
module.exports.Upload = function(folder_name,uniqname,type,file){
    const myDate = new Date()
    const month = myDate.getMonth()+1   
     const dateformat = type + "_"  + myDate.getDate() + month+ myDate.getFullYear()+ myDate.getHours()+ myDate.getMinutes()+ myDate.getSeconds() +myDate.getMilliseconds()
    const extname = file.originalname   
     const lextenstion = extname.split('.')
    // Adding image name is in userid ,
     var keyName = folder_name + uniqname + "_" +  dateformat + "." + lextenstion[lextenstion.length-1]
     console.log('keyname',keyName)
var params = {
    ACL: 'public-read',
    Bucket: 'bitzees',
    Key: keyName,
    Body: file.buffer,
};
s3.putObject(params, async function(err, data) {  
    if (err) console.log(err);
});
const url =  `https://bitzees.nyc3.cdn.digitaloceanspaces.com/${keyName}`
return url}
